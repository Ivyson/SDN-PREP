import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a sentence:");
        String sentence = scanner.nextLine().trim();

        if (sentence.isEmpty()) {
            System.out.println("No sentence entered.");
            scanner.close();
            return;
        }
// I would have used "\\W+" to split the sentence by non-word characters, but it would not have worked for words like "I'm" or "don't".
// Also, I am not sure if we should neglect the special characters or not, so I have not done that.
        StringTokenizer tokenizer = new StringTokenizer(sentence, " "); // Tokenize the sentence by space
        int wordCount = 0;
        int vowelStartCount = 0;
        StringBuilder output = new StringBuilder();

        while (tokenizer.hasMoreTokens()) {// checks if there are more tokens available
            String word = tokenizer.nextToken();
            if (!Character.isLetter(word.charAt(0))) { // Do not count a special character as a word (e.g. comma, period, etc.)
                continue;
            }
            wordCount++;

            if (isVowel(word.charAt(0))) {
                vowelStartCount++;
            }
            String capitalizedWord = capitalizeFirstLetter(word);
            output.append(capitalizedWord).append("\n");
            System.out.println(capitalizedWord);
        }

        System.out.println("Number of words: " + wordCount);
        System.out.println("Number of words starting with a vowel: " + vowelStartCount);

        output.append("Number of words: ").append(wordCount).append("\n");
        output.append("Number of words starting with a vowel: ").append(vowelStartCount).append("\n");

        try (FileWriter writer = new FileWriter("File.txt")) {
            writer.write(output.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        scanner.close();
    }
    private static boolean isVowel(char c) {
        return "AEIOUaeiou".indexOf(c) != -1;
    }

    private static String capitalizeFirstLetter(String word) {
        if (word == null || word.isEmpty()) {
            return word;
        }
        return word.substring(0, 1).toUpperCase() + word.substring(1).toLowerCase();
    }
}