import java.util.*;
/*
 * Name: Samukelo Gift Msimanga
 * Student Number: 223146145
 * Work Station : CR1_02
 */
public class Main {
    static Random random = new Random();
    public static <T> int searchElement(T element, T[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].equals(element)) {
                return i;
            }
        }
        return -1;
    }
    public static <T> void testSearchElement(T element, T[] array) {
        if(searchElement(element, array) >= 0 ){
            System.out.println(element + " Was found at the index "+searchElement(element, array)+" in the array: ");
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            if (i == array.length - 1) {
                System.out.print(array[i] + "]");
            } else {
                System.out.print(array[i] + ", ");
            }
        }
        }
        else{
            System.out.println(element + " was not found in the array");
            System.out.print("[");
            for (int i = 0; i < array.length; i++) {
                if (i == array.length - 1) {
                    System.out.print(array[i] + "]");
                } else {
                    System.out.print(array[i] + ", ");
                }
            }
        }
        System.out.println();
    }
    public static void main(String[] args) {
        Integer[] intArray = new Integer[10];
        for (int i = 0; i < intArray.length; i++) {
            intArray[i] = random.nextInt(50) + 1;
        }
        Double[] doubleArray = new Double[10];
        for (int i = 0; i < doubleArray.length; i++) {
            doubleArray[i] = random.nextDouble() * 50.0 + 1.0;
            doubleArray[i] = Math.round(doubleArray[i] * 100.0) / 100.0;            
        }
        String[] stringArray = {"blue", "red", "yellow", "green", "white", "cyan", "magenta", "grey", "black", "brown"};
        Scanner scanner = new Scanner(System.in);
        System.out.println();
        System.out.printf("Enter an element to Search for in the string array: ");
        String word = scanner.nextLine();
        System.out.println();
        System.out.printf("Enter an element to Search for in the Double array: ");
        Double key = scanner.nextDouble();
        System.out.println();
        System.out.printf("Enter an element to Search for in the Integer array: ");
        Integer key2 = scanner.nextInt();
        System.out.println();
        testSearchElement(word.toLowerCase(), stringArray);
        System.out.println();
        testSearchElement(key, doubleArray);
        System.out.println();
        testSearchElement(key2, intArray);
        scanner.close();
    }
}