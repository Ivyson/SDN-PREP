/*
 * Name: Samukelo Gift Msimanga
 * Student Number: 223146145
 * Work Station : CR1_02
 * Question 3
 * Note :: This programs requires you to enter the element in the console and then enter the other after a 
 * new line. This is because the console does not allow you to enter two elements in the same line.
 * So, when running, It prompts you to enter two integers, then you enter the first integer and press enter, 
 * Then you enter the second integer and press enter.
 */
// package Question;
public class Main {
    // public static int lessThan(int a, int b) {
    //     if(a < b) {
    //         return a;
    //     } else {
    //         return b;
    //     }
    // }
    public static <T extends Comparable<T>> T lessThan(T a, T b) {
        if(a.compareTo(b) < 0) {
            return a;
        } 
        else {
            return b;
        }
    }
    public static void test() {
        System.out.println("Enter two integers: ");
        int a = Integer.parseInt(System.console().readLine());
        int b = Integer.parseInt(System.console().readLine());
        System.out.println("The smaller of the two integers is: " + lessThan(a, b));
        System.out.println("Enter two doubles: ");
        double c = Double.parseDouble(System.console().readLine());
        double d = Double.parseDouble(System.console().readLine());
        System.out.println("The smaller of the two doubles is: " + lessThan(c, d));
        System.out.println("Enter two strings: ");
        // System.out.println("Enter the first string:");
        String e = System.console().readLine();
        String f = System.console().readLine();// Reads the string entered by the user in the console. Used this for my banking App
        System.out.println("The smaller of the two strings is: " + lessThan(e, f));
        System.out.println("Enter two characters: ");
        char g = System.console().readLine().charAt(0);
        char h = System.console().readLine().charAt(0);
        System.out.println("The smaller of the two characters is: " + (char)lessThan(g, h));//Casting the return value to a char, because this returns number(ASCII) value

    }
    public static void main(String[] args) {
        test();
    }
}